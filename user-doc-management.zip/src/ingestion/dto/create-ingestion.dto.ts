export class CreateIngestionDto {}
