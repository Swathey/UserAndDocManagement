export class Ingestion {}
